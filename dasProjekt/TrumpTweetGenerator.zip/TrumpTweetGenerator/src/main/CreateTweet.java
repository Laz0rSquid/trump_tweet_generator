package main;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CreateTweet {

	private List<String> headline = new ArrayList<String>();
	private List<String> bewertung = new ArrayList<String>();
	private List<String> aussage = new ArrayList<String>();
	private List<String> kommentar = new ArrayList<String>();

	public String createTweet() {

		Random randomizer = new Random();
		String random = headline.get(randomizer.nextInt(headline.size())) + " "
				+ bewertung.get(randomizer.nextInt(bewertung.size())) + " "
				+ aussage.get(randomizer.nextInt(aussage.size())) + " "
				+ kommentar.get(randomizer.nextInt(kommentar.size()));

		return random + "!";
	}

}
